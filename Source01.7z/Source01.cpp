#include <algorithm>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

struct student {
	std::string name, last_name;
	std::vector <int> marks;
	double average, mediana, final_mark;
	void input();
};

std::vector<student> students;

void student::input()
{
	int temp_mark, mark_index = 1, mark_amount;
	char random_mark_choice;
	std::cout << "Vardas: "; std::cin >> name;
	std::cout << "Pavarde: "; std::cin >> last_name;
	marks.clear();
	std::cout << "Generuoti atsitiktinius pazymius? t\n?"; std::cin >> random_mark_choice;
	switch (random_mark_choice) {
		case ('t'):
			std::cout << "Iveskite pazymiu kieki: "; std::cin >> mark_amount;
			for (int i = 0; i < mark_amount; i++) {
				marks.push_back(rand() % 10);
			}
			break;
		default:
			do {
				std::cout << mark_index << " pazymis: "; std::cin >> temp_mark;
				if (temp_mark > 0 && temp_mark <= 10) {
					marks.push_back(temp_mark);
					mark_index++;
				}
			} while (temp_mark != 0);
			break;
	}

	average = 0;
	for (int i : marks) {
		average += i;
	}
	average = double(average) / marks.size();
	sort(marks.begin(), marks.end());
	mediana = (marks.size() % 2 == 1) ? marks[marks.size() / 2] : double(marks[marks.size() / 2] + marks[marks.size() / 2 - 1]) / 2;
}

void output() {
	char output_choice;


	std::cout << "Nori matyti viduri ar mediana?  v/m:\n"; std::cin >> output_choice;

	std::cout << std::left << std::setw(15) << "Vardas" << std::left << std::setw(15) << "Pavarde" << std::right << std::setw(15) << "Galutinis paz. ";


	switch (output_choice) {
		case ('v'):
			std::cout << "(vid.)\n";
			break;
		case ('m'):
			std::cout << "(med.)\n";
			break;
		default:
			output_choice = 'v';
			break;
	}

	std::cout << "-" << std::setfill('-') << std::setw(50) << "-\n";
	std::cout << std::setfill(' ');
	for (student i : students) {
		std::cout << std::left << std::setw(15) << i.name << std::left << std::setw(15) << i.last_name << std::right << std::setw(21);

		output_choice == 'v' ? std::cout << std::fixed << std::setprecision(2) << i.average << std::endl : std::cout << std::fixed << std::setprecision(2) << i.mediana << std::endl;
	}
	std::cout << "-" << std::setfill('-') << std::setw(50) << "-\n";
	std::cout << std::setfill(' ');
}

int main() {

	student temp_stud;  char next_record;

	do {
		temp_stud.input();
		students.push_back(temp_stud);
		std::cout << "Kitas irasas? T/n:\n";
		std::cin >> next_record;
	} while (next_record == 't' || next_record == 'T');

	output();

}
