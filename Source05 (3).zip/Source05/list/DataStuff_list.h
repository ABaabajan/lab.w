#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <list>
#include <chrono>

using namespace std::chrono;

#ifndef DATASTUFF_H_INCLUDED
#define DATASTUFF_H_INCLUDED

struct student {
	std::string name, last_name;
	std::list <int> marks;
	double average, mediana, final_mark;
	int exam;
	void input();
	void autpildymas(std::string v, std::string p, int hw1, int hw2, int hw3, int hw4, int hw5, int exam);
};

std::list<student> students;

void student::input() {
	int temp_mark, mark_index = 1, mark_amount;
	char random_mark_choice;
	std::cout << "Vardas: "; std::cin >> name;
	std::cout << "Pavarde: "; std::cin >> last_name;
	marks.clear();
	std::cout << "Generuoti atsitiktinius pazymius? t\n?"; std::cin >> random_mark_choice;
	switch (random_mark_choice) {
	case ('t'):
		std::cout << "Iveskite pazymiu kieki: ";
		try {
			 std::cin >> mark_amount;
		} catch (std::exception& e) {
			std::cout << "ivedete ne skaiciu pazymiu kiekis bus parinktas i 5";
			mark_amount = 5;
		}
		for (int i = 0; i < mark_amount; i++) {
			marks.push_back(rand() % 10);
		}
		break;
	default:
		do {
			std::cout << mark_index << " pazymis: ";
			try {
				std::cin >> temp_mark;
			} catch (std::exception& e) {
				std::cout << "ivedete ne skaiciu pazimys bus parinktas i 10";
				temp_mark = 10;
			}
			if (temp_mark > 0 && temp_mark <= 10) {
				marks.push_back(temp_mark);
				mark_index++;
			}
		} while (temp_mark != 0);
		break;
	}

	average = 0;
	for (int i : marks) {
		average += i;
	}
	average = double(average) / marks.size();
	sort(marks.begin(), marks.end());
	mediana = (marks.size() % 2 == 1) ? marks[marks.size() / 2] : double(marks[marks.size() / 2] + marks[marks.size() / 2 - 1]) / 2;
}

void student::autpildymas(std::string f_name, std::string l_name, int hw1, int hw2, int hw3, int hw4, int hw5, int egz) {
	marks.clear();
	name = f_name;
	last_name = l_name;
	marks.push_back(hw1);
	marks.push_back(hw2);
	marks.push_back(hw3);
	marks.push_back(hw4);
	marks.push_back(hw5);
	exam = egz;

	average = double(hw1 + hw2 + hw3 + hw4 + hw5) / 5;
	final_mark = double(average * 0.4 + exam * 0.6);
}

void output() {
	char output_choice;


	std::cout << "Nori matyti viduri ar mediana?  v/m:\n"; std::cin >> output_choice;

	std::cout << std::left << std::setw(15) << "Vardas" << std::left << std::setw(15) << "Pavarde" << std::right << std::setw(15) << "Galutinis paz. ";


	switch (output_choice) {
	case ('v'):
		std::cout << "(vid.)\n";
		break;
	case ('m'):
		std::cout << "(med.)\n";
		break;
	default:
		output_choice = 'v';
		break;
	}

	std::cout << "-" << std::setfill('-') << std::setw(50) << "-\n";
	std::cout << std::setfill(' ');
	for (student i : students) {
		std::cout << std::left << std::setw(15) << i.name << std::left << std::setw(15) << i.last_name << std::right << std::setw(21);

		output_choice == 'v' ? std::cout << std::fixed << std::setprecision(2) << i.average << std::endl : std::cout << std::fixed << std::setprecision(2) << i.mediana << std::endl;
	}
	std::cout << "-" << std::setfill('-') << std::setw(50) << "-\n";
	std::cout << std::setfill(' ');
}

bool by_last_name(const student &a, const student &b)
{
	return a.last_name < b.last_name;
}

void output2() {
	sort(students.begin(), students.end(), by_last_name);

	std::cout << std::left << std::setw(15) << "Vardas" << std::left << std::setw(15) << "Pavarde" << std::right << std::setw(20) << "Galutinis(Vid.)" << std::right << std::setw(20) << "Galutinis(vid+egz)\n";
	std::cout << "-" << std::setfill('-') << std::setw(69) << "-\n";
	std::cout << std::setfill(' ');
	for (student x : students) {
		std::cout << std::left << std::setw(15) << x.name << std::left << std::setw(15) << x.last_name << std::right << std::setw(19) << std::fixed << std::setprecision(2) << x.average << std::right << std::setw(20) << std::fixed << std::setprecision(2)
			<< x.final_mark << std::endl;
	}
	std::cout << "-" << std::setfill('-') << std::setw(69) << "-\n";
	std::cout << std::setfill(' ');
}

void read_file() {
	std::ifstream is("student_data.txt");
	int nd1, nd2, nd3, nd4, nd5, egz, eil = 0;
	std::string lin, vard, pav;

	student student_temp1;

	while (getline(is, lin)) {
		is >> vard >> pav >> nd1 >> nd2 >> nd3 >> nd4 >> nd5 >> egz;
		student_temp1.autpildymas(vard, pav, nd1, nd2, nd3, nd4, nd5, egz);
		students.push_back(student_temp1);
		eil++;
	}
	is.close();
}

void choice() {
	char by_hand_choice;
	student temp_stud;  char next_record;
	std::cout << "Ar pazymius rasysite patys? t/n "; std::cin >> by_hand_choice;
	switch (by_hand_choice) {
	case ('t'):
		do {
			temp_stud.input();
			students.push_back(temp_stud);
			std::cout << "Kitas irasas? t/n: "; std::cin >> next_record;
		} while (next_record == 't');
		output();
		break;
	default:
		read_file();
		output2();
		break;
	}
}

#endif
