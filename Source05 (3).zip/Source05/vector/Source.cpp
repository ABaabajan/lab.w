#include "DataStuff.h"

int main() {
	choice();
	system("pause");
}
