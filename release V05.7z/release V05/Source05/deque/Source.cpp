#include "DataStuff_deque.h"

int main() {
	choice();
	system("pause");
}
