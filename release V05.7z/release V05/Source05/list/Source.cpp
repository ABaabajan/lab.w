#include "DataStuff_list.h"

int main() {
	choice();
	system("pause");
}
